Cryptography318 is a package intended for students of the MATH318 class
at Oberlin College. This package includes functions for generating primes,
testing composite numbers, solving DLP's, and working with matrices.

This package is unlicensed and for not intended for public use.